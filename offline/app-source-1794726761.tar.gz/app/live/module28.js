// ===== Diamonds: Done and Shipped, plus time spent on every task and bucket (one refMin) =====
// Pillar: procrastination (a quiet record of real progress lowers the cost of starting) and fear of overwhelm (display only, no new logging duty).
let refIx=null,refIxE=null,refIxT=0;
function refIndex(){const now=Date.now();if(refIx&&refIxE===state.entries&&now-refIxT<60000)return refIx;
  const ix={days:{},n:{},min:{}},ds=new Set(Object.keys(state.entries||{}));ds.add(iso(new Date()));
  ds.forEach(d=>{itemsOn(d).forEach(x=>{if(!x||typeof x.ref!=="string"||x.kind==="event"||x.kind==="break"||isEstimate(x))return;
    (ix.days[x.ref]=ix.days[x.ref]||new Set()).add(d);ix.n[x.ref]=(ix.n[x.ref]||0)+1;});});
  refIx=ix;refIxE=state.entries;refIxT=now;return ix;}
function refMin(ref){const ix=refIndex();if(ix.min[ref]!=null)return ix.min[ref];let m=0;(ix.days[ref]||new Set()).forEach(d=>{m+=workedMin(d,x=>x.ref===ref);});return ix.min[ref]=m;}
function refSessions(ref){return refIndex().n[ref]||0;}
function refLast(ref){const s=[...(refIndex().days[ref]||[])].sort();return s[s.length-1]||null;}
let dmKids=null;
function taskKids(id){if(dmKids)return dmKids[id]||[];return Object.entries(state.tasks||{}).filter(([k,x])=>x&&x.parent===id&&!x.bucket&&!x.deleted).map(([k])=>k);}
function taskMin(id,g){g=g||0;let m=refMin("tasks:"+id);if(g<6)taskKids(id).forEach(k=>{m+=taskMin(k,g+1);});return m;}
function taskSessions(id,g){g=g||0;let n=refSessions("tasks:"+id);if(g<6)taskKids(id).forEach(k=>{n+=taskSessions(k,g+1);});return n;}
function bkMin(bid){let m=refMin("tasks:"+bid);bkDescendants(bid).forEach(i=>{const t=state.tasks[i];if(t&&!t.deleted)m+=refMin("tasks:"+i);});return m;}
const spentTxt=m=>m>0?dur(m):"";
{const _se24=saveEntries;saveEntries=function(d,i){refIx=null;return _se24(d,i);};}
{const _ut24=urTags;urTags=function(t){const a=_ut24(t),s=t&&t.id&&!t.bucket?spentTxt(taskMin(t.id)):"";return s?(a?a+" · "+s:s):a;};}
{const _v24=v3card;v3card=function(t,top,ctx){const c=_v24(t,top,ctx);try{const head=c.querySelector(".cs-head"),s=t&&t.id&&!t.bucket?spentTxt(taskMin(t.id)):"";
  if(head&&s&&!head.querySelector(".tm-spent")){const sp=el("span",{class:"hint tm-spent",text:s});const a=head.querySelector(".bk-tag")||head.querySelector(".cat-chip");a?a.after(sp):head.append(sp);}}catch(e){console.warn(e);}return c;};}
{const _bc24=bkCard;bkCard=function(b){const c=_bc24(b);try{if(b){const s=c.querySelector(".bk-sub"),m=bkMin(b.id);if(s&&m>0&&!s.dataset.tm){s.dataset.tm="1";s.textContent+=" · "+dur(m)+" logged";}}}catch(e){console.warn(e);}return c;};}
let dmSheetBid=null;
{const _bs24=bkSheet;bkSheet=function(bid){dmSheetBid=bid;return _bs24(bid);};}
PS_AFTER.push((title,body)=>{const s=body.querySelector(".bks-sum");if(!s||s.dataset.tm||!dmSheetBid)return;const m=bkMin(dmSheetBid);s.dataset.tm="1";if(m>0)s.textContent+=" · "+dur(m)+" logged";});
let dmTaskId=null;
{const _ts24=v3taskSheet;v3taskSheet=function(id,edit){dmTaskId=id;return _ts24(id,edit);};try{if(window.__u)window.__u.v3taskSheet=v3taskSheet;}catch(e){}}
PS_AFTER.push((title,body)=>{if(title!=="Task"||body.querySelector(".tm-line"))return;const id=dmTaskId;if(!id||!state.tasks[id])return;const m=taskMin(id),n=taskSessions(id);
  const p=el("p",{class:"hint tm-line",text:m>0?"Time spent "+dur(m)+" · "+n+" session"+(n===1?"":"s"):"No time logged yet"});
  const nm=body.querySelector('[aria-label="Task name"]');nm?nm.after(p):body.prepend(p);});

// ----- data layer: records are derived live; only user writes go to the wins collection -----
const WINS={};
(async()=>{try{const d=await window.claude?.use?.("db");if(!d)return;d.collection("wins").onSnapshot(s=>{for(const k in WINS)delete WINS[k];s.docs.forEach(x=>{WINS[x.id]=x.data();});try{render();const a=document.activeElement;if(!(a&&a.closest&&a.closest(".ps-sheet")&&/INPUT|TEXTAREA/.test(a.tagName)))sheetRefresh();}catch(e){}});}catch(e){}})();
function dmSlug(s){return String(s||"Time entry").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,40)||"entry";}
function dmLastOf(id,g){g=g||0;let l=refLast("tasks:"+id);if(g<6)taskKids(id).forEach(k=>{const x=dmLastOf(k,g+1);if(x&&(!l||x>l))l=x;});return l;}
function dmTaskRecs(){const out=[];Object.entries(state.tasks||{}).forEach(([id,t])=>{if(!t||t.bucket||t.sub||t.deleted||!t.title)return;
  const min=taskMin(id),last=dmLastOf(id),done=!!(t.done&&t.doneAt);if(!done&&min<30)return;
  out.push({id:"t_"+id,kind:"task",diamond:"done",state:done?"done":"progress",ref:"tasks:"+id,title:t.title,cat:t.cat||null,date:done?(last&&last>t.doneAt?last:t.doneAt):last,min,sessions:taskSessions(id),note:t.desc||""});});return out;}
function dmHabitRecs(){const out=[],H=window.__hb?window.__hb.list(true):HABITS;
  (H||[]).forEach(h=>{const g={};Object.keys(state.logs||{}).forEach(k=>{const l=state.logs[k];if(l&&l[h.id]===true){const ws=v3wkStart(k);(g[ws]=g[ws]||[]).push(k);}});
    Object.keys(g).forEach(ws=>{const ds=g[ws].sort();out.push({id:"h_"+h.id+"_"+ws,kind:"habit",diamond:"done",state:"done",ref:"habits:"+h.id,title:h.name,date:ds[ds.length-1],days:ds.length,min:0});});});return out;}
function dmLabelRecs(){const out=[];const noTask=x=>typeof x.ref!=="string"||x.ref.indexOf("tasks:")!==0||!state.tasks[x.ref.slice(6)];
  Object.keys(state.entries||{}).forEach(d=>{const its=itemsRaw(d).filter(x=>x&&x.kind!=="event"&&x.kind!=="break"&&!isEstimate(x)&&noTask(x)),g={};
    its.forEach(x=>{const l=x.label||"Time entry";(g[l]=g[l]||[]).push(x);});
    Object.keys(g).forEach(l=>{const min=workedMin(d,y=>y.kind!=="event"&&y.kind!=="break"&&noTask(y)&&(y.label||"Time entry")===l);
      if(min>0)out.push({id:"l_"+d+"_"+dmSlug(l),kind:"label",diamond:"done",state:"done",title:l,cat:g[l][0].cat||null,date:d,min,sessions:g[l].length});});});return out;}
function dmShipRecs(){return bkList().filter(b=>b.shipped===true&&b.title).map(b=>({id:"p_"+b.id,kind:"ship",diamond:"shipped",state:"done",ref:"tasks:"+b.id,title:b.title,cat:b.cat||b.kind||null,date:b.shippedAt,start:b.bStart||null,min:bkMin(b.id),tasks:bkDescendants(b.id).filter(i=>state.tasks[i]&&!state.tasks[i].sub&&!state.tasks[i].deleted).length}));}
function dmManualRecs(){return Object.keys(WINS).filter(k=>WINS[k]&&WINS[k].kind==="manual"&&!WINS[k].deleted).map(k=>({...WINS[k],id:k,state:"done",min:Number(WINS[k].min)||0}));}
function dmMerge(r){const o=WINS[r.id];return o&&r.kind!=="manual"?{...r,title:o.title||r.title,date:o.date||r.date,note:o.note!=null?o.note:r.note,reflection:o.reflection||"",hidden:o.hidden||null}:{...r,reflection:(o&&o.reflection)||r.reflection||""};}
function winsAll(){dmKids={};Object.entries(state.tasks||{}).forEach(([k,x])=>{if(x&&x.parent&&!x.bucket&&!x.deleted)(dmKids[x.parent]=dmKids[x.parent]||[]).push(k);});try{return dmAll();}finally{dmKids=null;}}
function dmAll(){return [].concat(dmTaskRecs(),dmHabitRecs(),dmLabelRecs(),dmShipRecs(),dmManualRecs()).map(dmMerge).filter(r=>!r.hidden&&r.date).sort((a,b)=>(a.date<b.date?1:a.date>b.date?-1:String(a.title).localeCompare(String(b.title))));}
function winsDone(ws){return winsAll().filter(r=>r.diamond==="done"&&v3wkStart(r.date)===ws);}
function winsDoneCount(ws){return winsDone(ws).filter(r=>r.state==="done").length;}
function winsShipped(){return winsAll().filter(r=>r.diamond==="shipped");}
function projectTaskEffort(bid){return bkDescendants(bid).filter(i=>{const t=state.tasks[i];return t&&!t.sub&&!t.deleted;}).map(i=>({id:i,title:state.tasks[i].title,min:taskMin(i),doneAt:state.tasks[i].doneAt||null})).filter(x=>!(x.min===0&&!x.doneAt)).sort((a,b)=>b.min-a.min);}
function winPut(id,patch,msg,keep){const had=!!WINS[id],old={};Object.keys(patch).forEach(k=>{old[k]=had&&WINS[id][k]!==undefined?WINS[id][k]:null;});const now=Date.now();
  if(had){WINS[id]={...WINS[id],...patch,upd:now};store.update("wins/"+id,{...patch,upd:now}).catch(fail);}
  else{WINS[id]={...patch,created:now,upd:now};store.set("wins/"+id,WINS[id]).catch(fail);}
  render();if(!keep){try{sheetRefresh();}catch(e){}}
  if(msg!==false&&msg)v3undoToast(msg,()=>{if(had){WINS[id]={...WINS[id],...old,upd:Date.now()};store.update("wins/"+id,{...old,upd:Date.now()}).catch(fail);}else{delete WINS[id];store.del("wins/"+id).catch(fail);}render();try{sheetRefresh();}catch(e){}});}
function winHide(id){winPut(id,{hidden:Date.now()},"Hidden from Done");}
function winUnhide(id){winPut(id,{hidden:null},false);}
function winDelete(id){const w=WINS[id];winPut(id,{deleted:Date.now()},"Deleted: "+((w&&w.title)||"win"));}
function winRestore(id){const w=WINS[id];winPut(id,{deleted:null},"Restored: "+((w&&w.title)||"win"));}
function dmShipSet(bid,on){const b=state.tasks[bid];if(!b)return;const refr=()=>{render();try{sheetRefresh();}catch(e){}};
  if(on){const old={shipped:!!b.shipped,shippedAt:b.shippedAt||null};bkSet(bid,{shipped:true,shippedAt:iso(new Date())});bkArchive(bid,true);refr();v3undoToast("Shipped: "+b.title,()=>{bkArchive(bid,false);bkSet(bid,old);refr();});}
  else{const old={shipped:true,shippedAt:b.shippedAt||null};bkSet(bid,{shipped:false});bkArchive(bid,false);refr();v3undoToast("Back on the active list: "+b.title,()=>{bkSet(bid,old);bkArchive(bid,true);refr();});}}
{const _bm24=bkMenu;bkMenu=function(bid){_bm24(bid);try{const b=state.tasks[bid],sh=document.querySelector(".ps-sheet");if(!b||!sh||sh.querySelector(".dm-ship"))return;
  const un=b.shipped===true;
  const btn=el("button",{type:"button",class:"btn ghost dm-ship",onclick:()=>{psClose(true);dmShipSet(bid,!un);}},un?"Unship":"Mark shipped");
  const a=[...sh.querySelectorAll("button")].find(x=>/^Archive$/.test(x.textContent));a?a.before(btn):sh.querySelector(".ps-sh-body")?sh.querySelector(".ps-sh-body").append(btn):sh.append(btn);}catch(e){console.warn(e);}};
  try{if(window.__u)window.__u.bkMenu=bkMenu;}catch(e){}}

// ----- Today row and the Done sheet -----
let dmOpen={},dmSavedAt=0,dmTipNow=false;
const dmWk=()=>v3wkStart(iso(new Date()));
function dmRowUpdate(){try{const pc=document.getElementById("popCards");if(!pc)return;let row=document.getElementById("dmRow");
  if(!row)row=el("div",{class:"dm-row",id:"dmRow","aria-label":"Done and shipped"},...[["done","Done"],["shipped","Shipped"]].map(([k,l])=>el("button",{type:"button",class:"dm-btn","data-dm":k,onclick:()=>{if(k==="done")dmDoneSheet();else if(typeof dmShippedSheet==="function")dmShippedSheet();}},
    el("span",{class:"dm-ic"+(k==="shipped"?" ship":"")}),el("span",{class:"dm-w",text:l}),el("span",{class:"dm-n num"}))));
  if(pc.nextElementSibling!==row)pc.after(row);
  row.hidden=!!warGet();if(row.hidden)return;
  [["done",winsDoneCount(dmWk()),"Done this week: "],["shipped",winsShipped().length,"Shipped: "]].forEach(([k,n,a])=>{const b=row.querySelector('[data-dm="'+k+'"]');if(!b)return;
    const nn=b.querySelector(".dm-n");if(nn.textContent!==String(n))nn.textContent=String(n);b.querySelector(".dm-ic").classList.toggle("on",n>0);b.setAttribute("aria-label",a+n);});}catch(e){console.warn(e);}}
{const _rp24=renderPopCards;renderPopCards=function(){_rp24();dmRowUpdate();};}
{const _r24=render;render=function(){_r24();dmRowUpdate();};}
let dmFrom="done";
const dmList=()=>{if(dmFrom==="shipped"&&typeof dmShippedSheet==="function")dmShippedSheet();else dmDoneSheet();};
const dmBack={onClose:()=>setTimeout(()=>{if(!sheetStack.length&&Date.now()-(window.__psOutside||0)>400)dmList();},260)};
const dmCatTxt=r=>CAT_NAME[r.cat]||(r.cat?String(r.cat):"");
function dmTag(r){let t;if(r.state==="progress")t="in progress, "+dur(r.min)+" so far";else if(r.kind==="habit")t="habit · "+r.days+" day"+(r.days===1?"":"s");else if(r.kind==="label")t="time";else if(r.kind==="manual")t="manual";else t=CAT_NAME[r.cat]||"task";
  if(r.sessions>1)t+=" · "+r.sessions+" sessions";return t;}
function dmRowEl(r,open){const li=el("li",{class:"tr-row dm-r","data-id":r.id,tabindex:"0",role:"button","aria-label":r.title},
  el("span",{class:"dm-t",text:r.title}),el("span",{class:"hint dm-tag",text:dmTag(r)}),el("span",{class:"hint dm-d",text:fmt(r.date,{weekday:"short",day:"numeric"})}),el("span",{class:"num dm-m",text:r.min>0?dur(r.min):""}));
  li.onkeydown=e=>{if(e.key==="Enter")open();};
  swipeable(li,null,()=>winHide(r.id),open,{direct:true});rsLong(li,()=>dmRecMenu(r.id));return li;}
function dmDoneSheet(){dmFrom="done";dmTipNow=!localStorage.getItem("sb-dm-tip");try{localStorage.setItem("sb-dm-tip","1");}catch(e){}
  psOpen("Done",re=>{const cur=dmWk(),by={};winsAll().filter(r=>r.diamond==="done").forEach(r=>{const ws=v3wkStart(r.date);(by[ws]=by[ws]||[]).push(r);});by[cur]=by[cur]||[];
    const wks=Object.keys(by).sort().reverse();
    const secs=wks.map((ws,wi)=>{const L=by[ws],open=dmOpen[ws]===undefined?ws===cur:dmOpen[ws],n=L.filter(r=>r.state==="done").length,sum=L.reduce((a,r)=>a+(r.min||0),0),ex=!!dmOpen[ws+"x"];
      const kids=[el("button",{type:"button",class:"dm-wh","aria-expanded":String(open),onclick:()=>{dmOpen[ws]=!open;re();}},
        el("span",{class:"lh-wh",text:"Week of "+fmt(ws,{day:"numeric",month:"short"})}),el("span",{class:"lh-wn num",text:String(n)}),el("span",{class:"num dm-wt",text:sum>0?dur(sum):""}))];
      if(wi===0&&dmTipNow)kids.push(el("p",{class:"hint dm-tip",text:"Swipe left to hide, hold for more."}));
      if(open){if(!L.length)kids.push(el("p",{class:"hint dm-empty",text:"Nothing here yet this week. Finished tasks, habit days and logged effort land here by themselves."}));
        else{kids.push(el("ul",{class:"ps-sh-list dm-list"},...(ex?L:L.slice(0,4)).map(r=>dmRowEl(r,()=>dmRecSheet(r.id)))));
          if(L.length>4)kids.push(el("button",{type:"button",class:"mini ck-more",onclick:()=>{dmOpen[ws+"x"]=!ex;re();}},ex?"Show less":(L.length-4)+" more"));}}
      return el("section",{class:"lh-wk dm-wk"},...kids);});
    return [el("div",{class:"v3-row"},el("button",{type:"button",class:"btn ghost dm-add",onclick:()=>dmAddSheet("done")},"Add")),...secs];});}
function dmFind(id){return winsAll().find(r=>r.id===id);}
function dmRecMenu(id){const r=dmFind(id);if(!r)return;psOpen("Win options",()=>{const tid=r.ref&&r.ref.indexOf("tasks:")===0?r.ref.slice(6):null;
  return [el("p",{class:"ps-sh-sum",text:r.title}),
    el("button",{type:"button",class:"btn ghost",onclick:()=>{psClose(true);dmRecSheet(id,true);}},"Edit title and date"),
    el("button",{type:"button",class:"btn ghost",onclick:()=>{winHide(id);psClose(true);}},"Hide"),
    tid&&state.tasks[tid]&&!state.tasks[tid].bucket?el("button",{type:"button",class:"btn ghost",onclick:()=>{psClose(true);setTimeout(()=>v3taskSheet(tid),60);}},"Open task"):null];},{...dmBack});}
function dmRecSheet(id,edit){psOpen("Win",re=>{const r=dmFind(id);if(!r)return [el("p",{class:"ps-sh-sum",text:"This win is gone."})];
  const out=[el("p",{class:"ps-sh-sum",text:r.title}),el("p",{class:"hint",text:[fmt(r.date,{weekday:"long",day:"numeric",month:"long"}),r.min>0?dur(r.min):"",dmCatTxt(r)].filter(Boolean).join(" · ")})];
  if(r.note)out.push(el("p",{class:"hint dm-note",text:r.note}));
  if(edit){const ti=el("input",{type:"text",class:"v3-in dm-title","aria-label":"Title"});ti.value=r.title;ti.onchange=()=>{const v=ti.value.trim();if(v&&v!==r.title)winPut(id,{title:v},false);};
    const da=el("input",{type:"date",class:"tt-in dm-date","aria-label":"Date"});da.value=r.date;da.onchange=()=>{if(da.value&&da.value!==r.date)winPut(id,{date:da.value},false);};
    out.push(el("label",{class:"field"},el("span",{class:"label",text:"Title"}),ti),el("label",{class:"field"},el("span",{class:"label",text:"Date"}),da));}
  const ta=el("textarea",{class:"v3-in dm-refl",rows:"3",placeholder:"What did this take?","aria-label":"Reflection"});ta.value=r.reflection||"";
  const sv=el("span",{class:"hint dm-saved",text:"Saved"});sv.hidden=!(Date.now()-dmSavedAt<1500);
  ta.onblur=()=>{if(ta.value===(r.reflection||""))return;winPut(id,{reflection:ta.value},"Saved",true);dmSavedAt=Date.now();sv.hidden=false;setTimeout(()=>{sv.hidden=true;},1500);};
  out.push(el("label",{class:"field"},el("span",{class:"label",text:"Reflection"}),ta,sv));
  if(r.kind==="manual")out.push(el("div",{class:"v3-row"},el("button",{type:"button",class:"btn ghost dm-edit",onclick:()=>dmAddSheet(r.diamond,id)},"Edit"),el("button",{type:"button",class:"btn ghost danger dm-del",onclick:()=>{winDelete(id);psClose(true);}},"Delete")));
  return out;},{...dmBack});}

// ----- Shipped sheet, project record, manual items, recently deleted -----
const dmShort=d=>fmt(d,{day:"numeric",month:"short"});
function dmShippedSheet(){dmFrom="shipped";psOpen("Shipped",re=>{const L=winsShipped();
  return [el("div",{class:"v3-row"},el("button",{type:"button",class:"btn ghost dm-add",onclick:()=>dmAddSheet("shipped")},"Add")),
    L.length?el("ul",{class:"ps-sh-list dm-list"},...L.map(r=>{const open=()=>{if(r.kind==="ship")dmProjectSheet(r.id);else dmRecSheet(r.id);};
      const tag=r.kind==="ship"?[dmCatTxt(r)||"Project",r.tasks+" task"+(r.tasks===1?"":"s")].join(" · "):"manual";
      const li=el("li",{class:"tr-row dm-r","data-id":r.id,tabindex:"0",role:"button","aria-label":r.title},el("span",{class:"dm-t",text:r.title}),el("span",{class:"hint dm-tag",text:tag}),
        el("span",{class:"hint dm-d",text:(r.start?dmShort(r.start)+" to ":"")+dmShort(r.date)}),el("span",{class:"num dm-m",text:r.min>0?dur(r.min):""}));
      li.onclick=open;li.onkeydown=e=>{if(e.key==="Enter")open();};return li;})):el("p",{class:"hint",text:"Nothing shipped yet. Mark a bucket shipped from its menu."})];});}
function dmReflField(id,r){const ta=el("textarea",{class:"v3-in dm-refl",rows:"3",placeholder:"What did this take?","aria-label":"Reflection"});ta.value=r.reflection||"";
  const sv=el("span",{class:"hint dm-saved",text:"Saved"});sv.hidden=!(Date.now()-dmSavedAt<1500);
  ta.onblur=()=>{if(ta.value===(r.reflection||""))return;winPut(id,{reflection:ta.value},"Saved",true);dmSavedAt=Date.now();sv.hidden=false;setTimeout(()=>{sv.hidden=true;},1500);};
  return el("label",{class:"field"},el("span",{class:"label",text:"Reflection"}),ta,sv);}
const dmBackS={onClose:()=>setTimeout(()=>{if(!sheetStack.length&&Date.now()-(window.__psOutside||0)>400)dmShippedSheet();},260)};
function dmProjectSheet(id){psOpen("Project record",re=>{const r=dmFind(id);if(!r)return [el("p",{class:"ps-sh-sum",text:"This project is gone."})];const bid=id.slice(2);
  const E=projectTaskEffort(bid),ex=!!dmOpen.eff;
  const pt=el("p",{class:"ps-sh-sum dm-pt",text:r.title});rsLong(pt,()=>psOpen("Project options",()=>[el("p",{class:"ps-sh-sum",text:r.title}),el("button",{type:"button",class:"btn ghost dm-unship",onclick:()=>{psClose(true);dmShipSet(bid,false);}},"Unship")],{...dmBackS}));
  return [pt,el("p",{class:"hint",text:[(r.start?dmShort(r.start)+" to ":"")+dmShort(r.date),r.min>0?dur(r.min)+" logged":""].filter(Boolean).join(" · ")}),
    E.length?el("ul",{class:"ps-sh-list dm-eff"},...(ex?E:E.slice(0,4)).map(x=>el("li",{class:"dm-ef"},el("span",{text:x.title}),el("span",{class:"num",text:x.min>0?dur(x.min):""})))):null,
    E.length>4?el("button",{type:"button",class:"mini ck-more",onclick:()=>{dmOpen.eff=!ex;re();}},ex?"Show less":(E.length-4)+" more"):null,
    dmReflField(id,r)];},{...dmBackS});}
function dmAddSheet(diamond,editId){const r0=editId?dmFind(editId):null;let kind=(r0&&r0.diamond)||diamond;
  psOpen(editId?"Edit win":"Add a win",re=>{
    const ti=el("input",{type:"text",class:"v3-in dm-a-title",placeholder:"What did you finish?","aria-label":"Title"});ti.value=r0?r0.title:"";
    const da=el("input",{type:"date",class:"tt-in dm-a-date","aria-label":"Date"});da.value=r0?r0.date:iso(new Date());
    const mi=el("input",{type:"number",class:"v3-in dm-a-min",placeholder:"Minutes, optional",min:"0","aria-label":"Minutes"});if(r0&&r0.min)mi.value=String(r0.min);
    const no=el("textarea",{class:"v3-in dm-a-note",rows:"2",placeholder:"Note","aria-label":"Note"});no.value=r0?(r0.note||""):"";
    const rf=el("textarea",{class:"v3-in dm-a-refl",rows:"2",placeholder:"What did this take?","aria-label":"Reflection"});rf.value=r0?(r0.reflection||""):"";
    const seg=el("div",{class:"seg"},...[["done","Done"],["shipped","Shipped"]].map(([k,l])=>{const bt=el("button",{type:"button","aria-pressed":String(kind===k),onclick:()=>{kind=k;seg.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",String(x===bt)));}},l);return bt;}));
    return [el("label",{class:"field"},el("span",{class:"label",text:"Title"}),ti),el("label",{class:"field"},el("span",{class:"label",text:"Date"}),da),seg,mi,no,rf,
      el("button",{type:"button",class:"btn dm-a-save",onclick:()=>{const t=ti.value.trim();if(!t){toast("Give it a title");return;}
        const id=editId||"m_"+Date.now().toString(36);winPut(id,{kind:"manual",diamond:kind,title:t,date:da.value||iso(new Date()),min:Number(mi.value)||0,note:no.value.trim(),reflection:rf.value.trim()},editId?"Changed: "+t:"Added: "+t);
        psClose(true);dmList();}},"Save")];});}
PS_AFTER.push((title,body)=>{if(title!=="Recently deleted"||body.querySelector(".rd-win"))return;const D=Object.keys(WINS).filter(k=>WINS[k]&&WINS[k].kind==="manual"&&WINS[k].deleted);if(!D.length)return;
  body.append(el("div",{class:"rd-win"},el("p",{class:"hint",text:"Wins"}),el("ul",{class:"ps-sh-list rd-list"},...D.map(k=>el("li",{class:"bk-arow rd-row","data-win":k},el("span",{class:"rd-t",text:WINS[k].title||"Win"}),el("button",{type:"button",class:"mini rd-restore",onclick:()=>winRestore(k)},"Restore"))))));});
{const _ds28=v3deletedSec;v3deletedSec=function(){const e=_ds28(),n=Object.keys(WINS).filter(k=>WINS[k]&&WINS[k].kind==="manual"&&WINS[k].deleted).length;if(n){const b=e.querySelector(".rd-open"),m=b&&b.textContent.match(/\((\d+)\)$/);if(b)b.textContent="Recently deleted ("+((m?+m[1]:0)+n)+")";}return e;};}
try{if(typeof PH_GLOSS!=="undefined"){
  PH_GLOSS.push({id:"dm-done",g:"Records",t:"Done (diamonds)",w:"A quiet record of finished work, built from what you already did: done tasks, habit days and logged time. Nothing to log. Unfinished tasks with 30 min or more of effort show as in progress. Swipe a row left to hide it.",ex:"Done 7 this week, with the time under each."},
    {id:"dm-shipped",g:"Records",t:"Shipped (diamonds)",w:"A bucket you finished and sent. Mark it shipped from the bucket menu; it moves off the active list and keeps its total time and a reflection. Shipped counts all time.",ex:"HASM shipped on 8 Nov, 120 h logged."},
    {id:"dm-spent",g:"Time",t:"Time spent",w:"Total logged time on a task across all days, shown under the task, on the bucket header and in the task sheet. Overlapping entries count once.",ex:"Alpha: 3h 30m over 4 sessions."});
}}catch(e){console.warn(e);}
window.__dm={refMin,refSessions,refLast,taskMin,bkMin,winsAll,winsDone,winsDoneCount,winsShipped,projectTaskEffort,winPut,winHide,winUnhide,winDelete,winRestore,WINS,dmDoneSheet,dmShippedSheet};
