// ===== Round 2: checklists inside tasks, collapsed views, Start 5 min, Undo task diet =====
// checklist item: {t,done,o} stored as task.check = {<itemId>:{...}} (an object keyed by id so two devices never overwrite each other)
// subtasks: ONE concept. A subtask is a task doc {parent:<task id>, sub:true, title, done, order, cat, date, sprint}. It has no time of its own
// (the task carries the estimate), it never counts as a task (isLeaf is false for it) and it only shows as "n of m" on its parent.
// legacy: an old task.check list is shown until it is converted (ckEnsure converts it on open; apply_unify.py converts all of them)
function ckLegacy(t){const c=t&&t.check;if(!c)return [];const a=Array.isArray(c)?c.map((v,i)=>[v&&v.id||("i"+i),v]):Object.entries(c);
  return a.filter(([k,v])=>v&&v.t!=null).map(([k,v],i)=>({id:k,t:String(v.t),done:!!v.done,o:v.o!=null?v.o:i,legacy:true})).sort((x,y)=>x.o-y.o);}
function ckList(t){const id=t&&t.id;const L=id?subsOf(id).map((s,i)=>({id:s.id,t:String(s.title||""),done:!!s.done,o:s.order!=null?s.order:i})):[];return L.concat(ckLegacy(t));}
function ckCount(t){const L=ckList(t);return {n:L.length,d:L.filter(x=>x.done).length,next:L.find(x=>!x.done)||null};}
let ckBusy={};
async function ckEnsure(tid){const t=state.tasks[tid];if(!t||ckBusy[tid])return false;const L=ckLegacy(t);if(!L.length)return false;ckBusy[tid]=1;
  try{for(const x of L){await v3newTask({title:x.t,cat:t.cat||null,parent:tid,sub:true,done:x.done,order:x.o,date:t.date||null,sprint:t.sprint==null?null:t.sprint});}
    state.tasks[tid]={...state.tasks[tid],check:null};try{await store.update("tasks/"+tid,window.__sbSafe?{$d:[{p:["check"],del:1}]}:{check:null});}catch(e){fail(e);}}finally{delete ckBusy[tid];}
  return true;}
async function ckAdd(tid,text){text=String(text||"").trim();if(!text)return;const t=state.tasks[tid];if(!t)return;await ckEnsure(tid);const L=subsOf(tid),o=L.length?(L[L.length-1].order||0)+1:0;
  return v3newTask({title:text,cat:t.cat||null,parent:tid,sub:true,done:false,order:o,date:t.date||null,sprint:t.sprint==null?null:t.sprint});}
function ckEdit(id,text){text=String(text||"").trim();const s=state.tasks[id];if(!s||!text||text===s.title)return;const old=s.title;patchTask(id,{title:text});v3undoToast("Subtask renamed",()=>patchTask(id,{title:old}));}
function ckTick(id,on){patchTask(id,{done:!!on,doneAt:on?iso(new Date()):null});}
function ckDel(id){v3delete(id,true);}
function ckReorder(ids){const old=ids.map(i=>[i,(state.tasks[i]||{}).order]);ids.forEach((i,k)=>{if((state.tasks[i]||{}).order!==k)patchTask(i,{order:k});});v3undoToast("Subtasks reordered",()=>old.forEach(([i,o])=>patchTask(i,{order:o})));}
function ckRow(tid,s,re){const cb=el("input",{type:"checkbox","aria-label":"Done: "+s.t});cb.checked=s.done;cb.onchange=()=>{ckTick(s.id,cb.checked);setTimeout(re,250);};
  const ttl=el("span",{class:"ck-t ur-t"+(s.done?" v3-done":""),text:s.t});
  const acts=el("div",{class:"ck-acts",hidden:""},el("button",{type:"button",class:"mini",onclick:()=>{acts.hidden=true;const inp=el("textarea",{rows:"1",class:"v3-in ck-edit","aria-label":"Subtask name"});inp.value=s.t;ttl.replaceWith(inp);inp.focus();let ok=0;const done=()=>{if(ok)return;ok=1;ckEdit(s.id,inp.value);setTimeout(re,250);};inp.onblur=done;inp.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();inp.blur();}});}},"Rename"),
    el("button",{type:"button",class:"mini danger",onclick:()=>{ckDel(s.id);setTimeout(re,250);}},"Delete"));
  const more=el("button",{type:"button",class:"mini ck-more-btn","aria-label":"Menu for "+s.t,"aria-expanded":"false",onclick:()=>{acts.hidden=!acts.hidden;more.setAttribute("aria-expanded",String(!acts.hidden));}},"...");
  return el("li",{class:"q-row ck-row ur-row","data-id":s.id,"data-ck":s.id},cb,ttl,more,acts);}
// a dated task that sits under this task (an older nesting) shows in the same list: tick, title, quiet day, no time
function ckKidRow(s,re){const cb=el("input",{type:"checkbox","aria-label":"Done: "+s.title});cb.checked=!!s.done;cb.onchange=()=>{patchTask(s.id,{done:cb.checked,doneAt:cb.checked?iso(new Date()):null});setTimeout(re,250);};
  const li=el("li",{class:"q-row ck-row ur-row ck-kid v3-sub","data-id":s.id,"data-step":s.id},cb,el("span",{class:"ck-t"+(s.done?" v3-done":""),text:s.title}),s.date?el("span",{class:"hint ck-d",text:v3dl(s.date)}):null);
  if(s.date&&!s.done)v3stepSwipe(li,s);return typeof selRow==="function"?selRow(li,s.id):li;}
function ckSection(t,re){const id=t.id;if(ckLegacy(state.tasks[id]||t).length){ckEnsure(id).then(ok=>{if(ok)setTimeout(re,200);});}
  const L=ckList({...t,id}).filter(x=>!x.legacy),kids=kidsOf(id),n=L.length+kids.length,d=L.filter(x=>x.done).length+kids.filter(x=>x.done).length;
  const add=el("input",{type:"text",class:"v3-in ck-add","aria-label":"New subtask",placeholder:"Add a subtask"});
  add.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();const v=add.value;add.value="";ckAdd(id,v).then(()=>{re();setTimeout(()=>{const x=document.querySelector(".ps-sheet .ck-add");if(x)x.focus();},60);});}});
  const ul=el("ul",{class:"q-list ck-list"},...L.map(s=>ckRow(id,s,re)),...kids.map(k=>ckKidRow(k,re)));
  if(L.length>1)v3dragList(ul,".ck-row:not(.ck-kid)",ids=>{ckReorder(ids);setTimeout(re,250);});
  return el("section",{class:"ck-sec","aria-label":"Subtasks"},el("div",{class:"v3-row sel-head"},el("span",{class:"label",text:"Subtasks"+(n?" ("+d+" of "+n+")":"")}),kids.length&&typeof selStart==="function"&&!selOn?el("button",{type:"button",class:"hint bk-link sel-go",onclick:()=>selStart(null,re)},"Select"):null),n?ul:null,add);}
// Today card: "1 of 3 · next: ..." under the title
{const _vc=v3card;v3card=function(t,top,ctx){const c=_vc(t,top,ctx);try{const src=state.tasks[t.id]||t,k=ckCount({...src,id:t.id});
    if(k.n&&!c.querySelector(".ck-line")){const head=c.querySelector(".cs-head");const line=el("p",{class:"hint ck-line",text:k.d+" of "+k.n+(k.next?" · next: "+k.next.t:"")});if(head)head.after(line);else c.prepend(line);}
    // parent cards: 3 open steps, the rest behind "n more"
    const ul=c.querySelector(".cs-steps");if(ul){const lis=[...ul.children].filter(x=>!x.classList.contains("done"));
      if(lis.length>3){const key="card:"+t.id;const ex=!!ckExp[key];if(!ex)lis.slice(3).forEach(x=>x.hidden=true);
        ul.after(el("button",{type:"button",class:"mini ck-more",onclick:()=>{ckExp[key]=!ex;renderCutList();try{renderTaskView();}catch(e){}}},ex?"Show less":(lis.length-3)+" more"));}}
    const h=c.querySelector(".cs-t");if(h&&!h.dataset.li&&!h.dataset.ck){h.dataset.ck="1";h.classList.add("ck-open");h.setAttribute("role","button");h.addEventListener("pointerdown",e=>e.stopPropagation());h.addEventListener("click",e=>{e.stopPropagation();v3taskSheet(t.id);});if(!t.done)rsLong(h,()=>v3taskMenu(t.id));}
    if(c.querySelector(".cl-acts")&&cutDesc===t.id&&!t.done)c.querySelector(".cl-acts").append(el("button",{type:"button",class:"btn ghost",onclick:()=>v3five(t.id)},"Start for 5 minutes"));
  }catch(e){console.warn(e);}return c;};}
let ckExp={};
// counts of projects and tasks, never steps
function ckProjectRows(list,re){const g=new Map();list.forEach(t=>{const b=bkOfId(t.id),k=b||"none";if(!g.has(k))g.set(k,[]);g.get(k).push(t);});
  const out=[];[...g.entries()].forEach(([k,L])=>{const ex=!!ckExp["sp:"+k];out.push(el("li",{class:"v3-gh",text:(k==="none"?"No project":(state.tasks[k]||{}).title||"Project")+" ("+L.length+")"}));
    (ex?L:L.slice(0,3)).forEach(t=>out.push(v3taskRow(t,v3dl(t.date))));
    if(L.length>3)out.push(el("li",{},el("button",{type:"button",class:"mini ck-more",onclick:()=>{ckExp["sp:"+k]=!ex;re();}},ex?"Show less":(L.length-3)+" more")));});
  return out;}
function ckCountLine(list){const p=new Set(list.map(t=>bkOfId(t.id)||"none")).size;return el("p",{class:"hint ck-count",text:p+" project"+(p===1?"":"s")+", "+list.length+" task"+(list.length===1?"":"s")});}
// the little "1 of 3" on bucket rows
// ---- Start for 5 minutes: the existing focus timer, a 5 minute round on this task ----
function v3five(id){const t=state.tasks[id];if(!t)return;if(warGet()){v3start(id);return;}
  const r=pRun();if(r&&r.what==="tasks:"+id&&r.startedAt){openPomoFull();return;}
  pStartFor({what:"tasks:"+id,label:t.title,minutes:5});const r2=pRun();if(r2)setPomo({...r2,five:true});}
function v3keep(){const r=pRun();if(!r)return;setPomo({...r,five:false,overAt:null,overAs:null,block:null,round:1,durationMs:pElapsed(r)+20*60000});toast("Keep going. 20 more minutes.");}
{const _po=pOver;pOver=function(r){if(r&&r.five&&r.phase==="focus"){const endAt=r.startedAt+(r.pausedTotal||0)+r.durationMs;setPomo({...r,overAt:endAt,overAs:"focus"});toast("5 minutes done. Keep going or stop here, both are fine.");say("5 minutes done");return;}return _po(r);};}
{const _nl=pNextLabel;pNextLabel=function(r){if(r&&r.five)return "Stop here";return _nl(r);};}
{const _eb=extBtns;extBtns=function(cls){const d=_eb(cls),r=pRun();if(d&&r&&r.five&&r.overAt&&!d.querySelector(".ck-keep"))d.prepend(el("button",{type:"button",class:cls+" ck-keep",onclick:v3keep},"Keep going"));return d;};}
// ---- task diet: apply and roll back, with a record in diet/<runId> ----
// rows: {op:"create",id?,doc} | {op:"patch",id,fields}. Returns the run id.
async function dietApply(rows,label){const runId="diet-"+Date.now(),rec={at:Date.now(),label:label||"Task diet",created:[],patched:{},n:0};
  for(const r of rows){if(r.op==="create"){let id=r.id;if(id){await store.set("tasks/"+id,r.doc);}else{const ref=await store.add("tasks",r.doc);id=ref.id;}rec.created.push(id);state.tasks[id]=r.doc;}
    else if(r.op==="patch"){const t=state.tasks[r.id];if(!t)continue;const old={};Object.keys(r.fields).forEach(k=>{old[k]=t[k]===undefined?null:JSON.parse(JSON.stringify(t[k]));});rec.patched[r.id]={...(rec.patched[r.id]||{}),...old};
      state.tasks[r.id]={...t,...r.fields};await store.update("tasks/"+r.id,r.fields);}}
  rec.n=rec.created.length+Object.keys(rec.patched).length;await store.set("diet/"+runId,rec);state.diet={...(state.diet||{}),[runId]:rec};render();return runId;}
async function dietRollback(runId){const rec=(state.diet||{})[runId];if(!rec||rec.undone)return false;
  for(const id of rec.created||[]){delete state.tasks[id];await store.del("tasks/"+id);}
  for(const [id,old] of Object.entries(rec.patched||{})){if(!state.tasks[id])continue;state.tasks[id]={...state.tasks[id],...old};await store.update("tasks/"+id,old);}
  const nr={...rec,undone:true,undoneAt:Date.now()};state.diet={...state.diet,[runId]:nr};await store.set("diet/"+runId,nr);render();return true;}
function dietSheet(){psOpen("Undo task diet",re=>{const runs=Object.entries(state.diet||{}).filter(([k,r])=>r&&!r.undone).sort((a,b)=>b[1].at-a[1].at);
  return runs.length?[el("p",{class:"hint",text:"One tap puts the tasks back as they were. Undo is on the bar below."}),el("ul",{class:"ps-sh-list"},...runs.map(([k,r])=>el("li",{},el("button",{type:"button",class:"ps-sh-row",onclick:async()=>{psClose(true);const ok=await dietRollback(k);toast(ok?"Tasks put back":"Nothing to undo");}},
    fmt(iso(new Date(r.at)),{day:"numeric",month:"short"})+": "+(r.label||"Task diet")+" ("+(r.n||0)+" changes)"))))]:[el("p",{class:"hint",text:"Nothing to undo"})];});}
function dietRow(){const rows=document.querySelector('.page[data-page="settings"] .set-rows');if(!rows||document.getElementById("dietRow"))return;
  rows.append(el("div",{class:"set-row",id:"dietRow"},el("div",{},el("b",{text:"Undo task diet"}),el("span",{class:"hint",text:"Put the tasks back as they were before a clean-up"})),el("button",{type:"button",class:"btn ghost",id:"dietBtn",onclick:dietSheet},"Open")));}
{const _r7=render;render=function(){_r7();try{dietRow();}catch(e){}};}
window.dietApply=dietApply;window.dietRollback=dietRollback;window.v3five=v3five;
window.__r2={pStop:()=>pStop(),closeFull:()=>{try{closePomoFull();}catch(e){}},setPage:p=>setPage(p)};
window.__r2.ckAdd=ckAdd;
__r2.psClose=()=>psClose(true);

// ===== Round 2B: the day as chunk cards (Block 1, Block 2, Stretch, Learning, Shallow batch) =====
// `block` already means Learning/Design/Batch on tasks (taskBlock), so the design slot lives in `slot` (1, 2 or 3).
const CH_DEF={b1:{start:"05:15",h:4},b2:{start:"09:45",h:4},b3:{start:"15:00",h:2,stretch:true},learn:{minMin:30,targetMin:60},shallowMin:120};
function chCfg(){const s=(state.settings&&state.settings.blocks)||{},g=k=>({...CH_DEF[k],...(s[k]||{})}),L={...CH_DEF.learn,...(s.learn||{})};
  L.minMin=Math.max(30,Number(L.minMin)||30);L.targetMin=Math.max(L.minMin,Number(L.targetMin)||60);
  const n=k=>{const o=g(k);o.h=Number(o.h)>0?Number(o.h):CH_DEF[k].h;return o;};
  return {b1:n("b1"),b2:n("b2"),b3:n("b3"),learn:L,shallowMin:Number(s.shallowMin)>0?Number(s.shallowMin):120};}
const CH_DEEP=["portfolio","client","learning"];
function modeOf(t){const m=t&&t.mode;if(m==="deep"||m==="shallow")return m;return CH_DEEP.includes(t&&t.cat)?"deep":"shallow";}
function chKind(t){if(modeOf(t)==="shallow")return "shallow";return t.cat==="learning"?"learn":"design";}
function chBk(t){if(t.id&&state.tasks[t.id]){const b=bkOfId(t.id);if(b)return b;}
  if(t.parent){return isBk(t.parent)?t.parent:(bkOfId(t.parent)||t.parent);}return "c:"+(t.cat||"x");}
function chBkName(k){if(String(k).startsWith("c:"))return CAT_NAME[String(k).slice(2)]||"Design";const p=state.tasks[k];return (p&&p.title)||"Project";}
// design tasks of a day to slots: explicit `slot` first, then a bucket joins its slot, else the first free slot, else Stretch
function chAssign(d,exId){const des=tasksOn(d).filter(t=>t.id!==exId&&chKind(t)==="design"),slotOf={},held={1:new Set(),2:new Set(),3:new Set()};
  des.forEach(t=>{const s=Number(t.slot);if(s>=1&&s<=3){slotOf[t.id]=s;held[s].add(chBk(t));}});
  const groups=new Map();des.forEach(t=>{if(slotOf[t.id])return;const k=chBk(t);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(t);});
  groups.forEach((ts,k)=>{let s=[1,2,3].find(n=>held[n].has(k));if(!s)s=[1,2,3].find(n=>!held[n].size);if(!s)s=3;held[s].add(k);ts.forEach(t=>{slotOf[t.id]=s;});});
  return {slotOf,held};}
function chunkOf(t){const d=t.date,k=chKind(t);if(k==="learn")return d+"|learn";if(k==="shallow")return d+"|shallow";
  const A=chAssign(d,null),s=A.slotOf[t.id]||Number(t.slot)||1;return d+"|"+s+"|"+chBk(t);}
function chunksOn(d){const A=chAssign(d,null),ch={b1:{kind:"b1",slot:1,tasks:[]},b2:{kind:"b2",slot:2,tasks:[]},b3:{kind:"b3",slot:3,tasks:[]},learn:{kind:"learn",tasks:[]},shallow:{kind:"shallow",tasks:[]}};
  tasksOn(d).forEach(t=>{const k=chKind(t);if(k==="design")ch["b"+A.slotOf[t.id]].tasks.push(t);else ch[k].tasks.push(t);});
  return ["b1","b2","b3","learn","shallow"].map(k=>({...ch[k],key:d+"|"+k,held:ch[k].slot?[...A.held[ch[k].slot]]:[]}));}
// where a dated task goes. Returns the fields to write: {slot,mode}
function placeInChunk(t,d){const k=chKind(t),mode=t.mode==="deep"||t.mode==="shallow"?t.mode:modeOf(t);
  if(k!=="design")return {slot:null,mode};
  const A=chAssign(d,t.id),bk=chBk(t);let s=[1,2,3].find(n=>A.held[n].has(bk));if(!s)s=[1,2,3].find(n=>!A.held[n].size);if(!s)s=3;return {slot:s,mode};}
function workHoursDone(d){return pomN(v3workMin(d));}
function learnDone(d){return Math.round(learningOn(d)*60);}
function inBlock(now){const c=chCfg(),m=now==null?(()=>{const n=new Date();return n.getHours()*60+n.getMinutes();})():(now instanceof Date?now.getHours()*60+now.getMinutes():Number(now));
  for(const k of ["b1","b2","b3"]){const s=hmMin(c[k].start);if(m>=s&&m<s+c[k].h*60)return k;}return null;}
// placement hooks: a dated task is added, or its date changes
{const _add=store.add;store.add=function(col,body){try{if(col==="tasks"&&body&&body.date&&body.slot===undefined&&!body.bucket&&!body.cut){const pl=placeInChunk({...body,id:"__new"},body.date);body.mode=pl.mode;if(pl.slot)body.slot=pl.slot;}}catch(e){console.warn(e);}return _add.apply(this,arguments);};}
let chSkip=false;const chSnap={};
{const _st=setTask;setTask=function(id,patch){try{if(!chSkip&&patch&&typeof patch.date==="string"&&patch.slot===undefined){const t=state.tasks[id];
      if(t&&isLeaf({...t,id})){(chSnap[id]=chSnap[id]||[]).push({slot:t.slot===undefined?null:t.slot,mode:t.mode===undefined?null:t.mode});if(chSnap[id].length>6)chSnap[id].shift();
        const pl=placeInChunk({...t,id},patch.date);patch={...patch,...pl};state.tasks[id]={...state.tasks[id],...pl};}}}catch(e){console.warn(e);}
    return _st.call(this,id,patch);};}
{const _ru=v3recUndo;v3recUndo=function(rec){chSkip=true;try{_ru(rec);}finally{chSkip=false;}
    try{(rec.moves||[]).forEach(m=>{const s=(chSnap[m.id]||[]).pop();if(s&&state.tasks[m.id]){state.tasks[m.id]={...state.tasks[m.id],slot:s.slot,mode:s.mode};setTask(m.id,{slot:s.slot,mode:s.mode});}});}catch(e){console.warn(e);}};}
// cards of one chunk: same grouping as cardsOn (a parent with its steps)
function chCards(tasks,d){const groups=new Map();
  tasks.forEach(l=>{const p=l.parent&&state.tasks[l.parent]&&!state.tasks[l.parent].bucket&&!state.tasks[l.parent].cut&&!state.tasks[l.parent].archived?l.parent:null,key=p||l.id;
    if(!groups.has(key))groups.set(key,{key,p,steps:[]});groups.get(key).steps.push(l);});
  return [...groups.values()].map(g=>{if(!g.p)return {...g.steps[0],rank:slotRank(g.steps[0].cat)};
    const P=state.tasks[g.p],steps=g.steps.sort((a,b)=>(a.order||0)-(b.order||0));
    return {...P,id:g.p,steps,_card:true,date:d,cat:P.cat||steps[0].cat,mins:steps.reduce((a,s)=>a+estMin(s),0),done:steps.every(s=>s.done),order:Math.min(...steps.map(s=>s.order||0)),rank:slotRank(P.cat||steps[0].cat)};})
    .sort((a,b)=>{const pa=a.pos!=null,pb=b.pos!=null;if(pa&&pb)return a.pos-b.pos;if(pa!==pb)return pa?-1:1;return (a.rank-b.rank)||((a.order||0)-(b.order||0));});}
let chWar=null;
{const _wp=warPool;warPool=function(tg){if(chWar&&Date.now()-chWar.at<300000&&tg&&tg.k==="task"&&tg.v===chWar.v){return chWar.ids.map(id=>({id,...state.tasks[id]})).filter(x=>x.title);}return _wp(tg);};}
function chStart(cards){const first=cards[0];if(!first)return;const ids=[];cards.forEach(c=>{(c.steps?c.steps.filter(s=>!s.done):[c]).forEach(s=>ids.push(s.id));});chWar={v:first.id,ids,at:Date.now()};v3start(first.id);}
let chBuild=false;{const _sw=swipeable;swipeable=function(c,r,l,tap,...rest){return _sw.call(this,c,r,l,chBuild?null:tap,...rest);};}
let chTog={},chExp={};
const chH=h=>(Math.round(h*10)/10)+" h";
function chTitle(c,cfg,total){
  if(c.kind==="learn")return c.tasks.length?"Learning · "+(cfg.learn.targetMin%60?cfg.learn.targetMin+" min":chH(cfg.learn.targetMin/60)):"Learning: none planned, minimum "+cfg.learn.minMin+" min";
  if(c.kind==="shallow"){const open=c.tasks.filter(t=>!t.done);return "Shallow batch · "+open.length+" item"+(open.length===1?"":"s")+" · "+dur(open.reduce((a,t)=>a+estMin(t),0));}
  const n=c.kind==="b3"?"Stretch":"Block "+c.slot,names=[...new Set(c.tasks.map(t=>chBkName(chBk(t))))];
  if(c.kind==="b3")return "Stretch · "+chH(cfg.b3.h);
  return (names.length>1?names.length+" projects in "+n:n+" · "+(names[0]||"Design"))+" · "+chH(chunkCap(c.key.slice(0,10),c.kind)/60);}
function chDefaultOpen(d,chunks){const by={};chunks.forEach(c=>{by[c.kind]=c;});const op=c=>c&&c.tasks.some(t=>!t.done);
  const des=["b1","b2","b3"];
  if(d===iso(new Date())){const c=chCfg(),n=new Date(),m=n.getHours()*60+n.getMinutes(),e1=hmMin(c.b1.start)+c.b1.h*60,e2=hmMin(c.b2.start)+c.b2.h*60;
    if(m<e2){const cur=m<e1?"b1":"b2",order=[cur,...des.filter(k=>k!==cur)];const k=order.find(k=>op(by[k]));return k||null;}
    return op(by.learn)?"learn":op(by.shallow)?"shallow":"learn";}
  return [...des,"learn","shallow"].find(k=>op(by[k]))||null;}
function chRender(){const ul=document.getElementById("cutStack");if(!ul)return;const d=sel,cfg=chCfg(),chunks=chunksOn(d),by={};chunks.forEach(c=>{by[c.kind]=c;});
  const doneH=workHoursDone(d),baseH=pomN(v3dayMin(d)),defOpen=chDefaultOpen(d,chunks),nodes=[];
  const design=chunks.filter(c=>c.slot&&c.tasks.length);
  const card=(c,visible)=>{const open0=chTog[c.key]!=null?chTog[c.key]:c.kind===defOpen,hasItems=c.tasks.length>0,allDone=hasItems&&c.tasks.every(t=>t.done),open=open0&&hasItems&&!allDone;
    const title=chTitle(c,cfg)+(allDone?" · done":capOverText(c));
    const head=el("button",{type:"button",class:"ch-head","aria-expanded":String(open),disabled:hasItems&&!allDone?null:"",onclick:()=>{chTog[c.key]=!open;renderCutList();}},el("span",{class:"ch-t",text:title}),hasItems&&!allDone&&rlFromText(c.tasks,d)?el("span",{class:"hint ch-from",text:rlFromText(c.tasks,d)}):null,hasItems&&!allDone?el("span",{class:"hint ch-s",text:open?"Less":"Open"}):null);
    if(hasItems&&!allDone)rsLong(head,()=>rlMoveSheet(c.tasks,rlChunkName(c)));
    let body=null;
    if(open){const cards=chCards(c.tasks,d).filter(x=>!x.done),ex=!!chExp[c.key],show=ex?cards:cards.slice(0,3);chBuild=true;
      try{const list=el("div",{class:"ch-list"},...show.map(x=>v3card(x,false,"stack")));
        if(show.length>1)v3dragList(list,".cs-card",ids=>{const held=list.querySelector(".cs-card[data-dragged]");if(ids.join()===show.map(x=>x.id).join()){if(held)setTimeout(()=>v3taskMenu(held.dataset.id),0);return;}const rest=cards.filter(x=>!show.includes(x)).map(x=>x.id),all=ids.concat(rest),old=all.map(i=>[i,(state.tasks[i]||{}).pos]);v3reorder(all);render();v3undoToast("Order changed",()=>{old.forEach(([i,p])=>patchTask(i,{pos:p==null?null:p}));render();});});
        const first=cards[0],stepId=first&&(first.steps?(first.steps.find(s=>!s.done)||first.steps[0]).id:first.id);
        body=el("div",{class:"ch-body"},list,cards.length>3?el("button",{type:"button",class:"mini ck-more",onclick:()=>{chExp[c.key]=!ex;renderCutList();}},ex?"Show less":(cards.length-3)+" more"):null,
          el("div",{class:"cl-acts ch-acts"},el("button",{type:"button",class:"btn cl-go ch-go",onclick:()=>chStart(cards)},"Start"),el("button",{type:"button",class:"btn ghost ch-five",onclick:()=>v3five(stepId)},"Just 5 minutes")),el("button",{type:"button",class:"mini ck-more rl-mv",onclick:()=>rlMoveSheet(c.tasks,rlChunkName(c))},"Move chunk"));
      }finally{chBuild=false;}}
    return el("section",{class:"ch-card"+(open?" open":"")+(allDone?" done":"")+(!allDone&&capOver(c)>0?" ch-over":""),"data-ch":c.kind,"aria-label":title},head,body);};
  if(!design.length)nodes.push(el("p",{class:"hint ch-empty",text:"No design block planned"}));
  design.forEach(c=>nodes.push(card(c)));
  if(!by.b3.tasks.length&&baseH>0&&doneH>=baseH&&!isFriday(d))nodes.push(el("section",{class:"ch-card ch-free","data-ch":"b3","aria-label":"Stretch free"},el("div",{class:"ch-head ch-line"},el("span",{class:"ch-t",text:"Stretch · free"}))));
  nodes.push(card(by.learn));
  if(by.shallow.tasks.length)nodes.push(card(by.shallow));
  rc(ul,...nodes);}
{const _rc=renderCutList;renderCutList=function(){_rc();try{chRender();}catch(e){console.warn(e);}};}
// header: Work x of 8 h · Learning x of 30 min · Gate 1
v3dayNum=function(nm,wk,tg,d){const cfg=chCfg(),f=nm.closest(".dbar-focus"),stretchH=pomN(tg)+cfg.b3.h;
  nm.textContent="";nm.append(document.createTextNode("Work "+pomS(wk)+" of "+pomS(tg)+" h "),el("small",{class:"v3-pmin",text:dur(wk)}));
  if(!f)return;let hd=f.querySelector(".ch-hdr");if(!hd){hd=el("p",{class:"hint ch-hdr"});f.append(hd);}
  let gate="";try{const n=Math.round((parse(END)-parse(iso(new Date())))/864e5);gate=n>=0?"Gate 1: "+fmt(END,{day:"numeric",month:"short"})+", "+n+" day"+(n===1?"":"s"):"Gate 1: "+fmt(END,{day:"numeric",month:"short"});}catch(e){}
  const met=pomN(wk)>=stretchH?"Stretch met":(wk>=tg?"Baseline met":""),lmet=learnDone(d)>=cfg.learn.minMin?"Learning minimum met":"";
  hd.textContent=(isFriday(d)?"":"Stretch "+(Math.round((pomN(tg)+cfg.b3.h)*10)/10)+" h · ")+"Learning "+learnDone(d)+" of "+cfg.learn.minMin+" min"+(gate?" · "+gate:"")+(met?" · "+met:"")+(lmet?" · "+lmet:"");
  try{capHeaderFacts(f,d);}catch(e){console.warn(e);}
  let pl=f.querySelector(".v3-planned");const pm=planMins(d);if(!pl){pl=el("span",{class:"hint v3-planned"});f.append(pl);}pl.hidden=!pm;pl.textContent=pm?"planned "+pomS(pm)+" of "+pomS(tg)+" h":"";};
// the task sheet: deep or shallow
function chModeRow(t,re){const cur=modeOf(t),b=(m,txt)=>el("button",{type:"button",class:"mini ch-mode"+(cur===m?" on":""),"aria-pressed":String(cur===m),onclick:()=>{chSetMode(t.id,m);setTimeout(re,250);}},txt);
  return el("div",{class:"field ch-moderow"},el("span",{class:"label",text:"Block type"}),el("div",{class:"v3-row"},b("deep","Deep"),b("shallow","Shallow")));}
function chSetMode(id,m){const t=state.tasks[id];if(!t||modeOf(t)===m)return;const pl=t.date?placeInChunk({...t,mode:m,id},t.date):{slot:null};patchTask(id,{mode:m,slot:pl.slot||null});toast(m==="shallow"?"Moved to the shallow batch":"Moved to a deep block");}
// Settings: day blocks
function chSave(next,msg){{const c=chCfg();if(JSON.stringify([c.b1,c.b2,c.b3,c.learn,c.shallowMin])===JSON.stringify([next.b1,next.b2,next.b3,next.learn,next.shallowMin]))return;}const old={blocks:(state.settings||{}).blocks||null,work:(state.settings||{}).work||null,prefs:(state.settings||{}).prefs||null};
  const bl={...next,at:Date.now()},tH=Number(next.b1.h)+Number(next.b2.h),wk={targetH:tH,stretchH:tH+Number(next.b3.h),at:Date.now()},pf={...((state.settings&&state.settings.prefs)||{}),dayMin:Math.round(tH*50),at:Date.now()};
  state.settings={...(state.settings||{}),blocks:bl,work:wk,prefs:pf};
  try{store.set("settings/blocks",bl);store.set("settings/work",wk);store.set("settings/prefs",pf);}catch(e){fail(e);}
  v3undoToast(msg||"Blocks saved",()=>{const s={...(state.settings||{})};["blocks","work","prefs"].forEach(k=>{if(old[k]){s[k]=old[k];try{store.set("settings/"+k,old[k]);}catch(e){}}else{delete s[k];try{store.del("settings/"+k);}catch(e){}}});state.settings=s;render();});render();}
function chBlocksSheet(){psOpen("Day blocks",re=>{const cfg=chCfg();
    const num=(v,lab,fn,step,min)=>{const i=el("input",{type:"number",class:"v3-in",step:String(step||.5),min:String(min||0),value:String(v),"aria-label":lab});i.onchange=()=>fn(Number(i.value));return el("label",{class:"field"},el("span",{class:"label",text:lab}),i);};
    const tim=(v,lab,fn)=>{const i=el("input",{type:"time",class:"v3-in",value:v,"aria-label":lab});i.onchange=()=>{if(/^\d{2}:\d{2}$/.test(i.value))fn(i.value);};return el("label",{class:"field"},el("span",{class:"label",text:lab}),i);};
    const set=(k,f,v)=>{const c=chCfg(),n={b1:{...c.b1},b2:{...c.b2},b3:{...c.b3},learn:{...c.learn},shallowMin:c.shallowMin};if(k==="shallowMin")n.shallowMin=v;else n[k][f]=v;chSave(n);setTimeout(re,200);};
    const hrs=(k,lab)=>[tim(cfg[k].start,lab+" starts",v=>set(k,"start",v)),num(cfg[k].h,lab+" hours",v=>{if(!(v>=.5&&v<=8)){toast("Hours between 0.5 and 8");re();return;}set(k,"h",v);})];
    return [el("p",{class:"hint",text:"Baseline is Block 1 plus Block 2. Stretch is optional. Learning has a floor of 30 minutes."}),
      el("div",{class:"v3-row"},...hrs("b1","Block 1")),el("div",{class:"v3-row"},...hrs("b2","Block 2")),el("div",{class:"v3-row"},...hrs("b3","Stretch")),
      el("div",{class:"v3-row"},num(cfg.learn.minMin,"Learning minimum (min)",v=>{if(v<30){toast("Learning minimum cannot go below 30 min");re();return;}set("learn","minMin",v);},5,30),num(cfg.learn.targetMin,"Learning target (min)",v=>{if(!(v>=cfg.learn.minMin)){toast("Target is at least the minimum");re();return;}set("learn","targetMin",v);},5,30)),
      el("div",{class:"v3-row"},num(cfg.shallowMin,"Shallow batch (min)",v=>{if(!(v>=10)){re();return;}set("shallowMin",null,v);},10,10))];});}
function chBlocksRow(){const rows=document.querySelector('.page[data-page="settings"] .set-rows');if(!rows||document.getElementById("chBlocksRow"))return;
  rows.append(el("div",{class:"set-row",id:"chBlocksRow"},el("div",{},el("b",{text:"Day blocks"}),el("span",{class:"hint",text:"Hours for Block 1, Block 2, Stretch, Learning and the shallow batch"})),el("button",{type:"button",class:"btn ghost",id:"chBlocksBtn",onclick:chBlocksSheet},"Open")));}
{const _r8=render;render=function(){_r8();try{chBlocksRow();}catch(e){}};}
window.__ch={openAll:()=>{chunksOn(sel).forEach(c=>{chTog[c.key]=true;});renderCutList();},setMode:(i,m)=>chSetMode(i,m),moveTaskTo:(i,d)=>moveTaskTo(i,d),taskSheet:i=>v3taskSheet(i),addEntry:(d,x)=>addEntry(d,x),chunksOn,chunkOf,placeInChunk,modeOf,inBlock,workHoursDone,learnDone,chCfg,sheet:chBlocksSheet};

// ===== Round 3: quiet carry-forward, Waiting tray, Spread, Move chunk, decide after 3 =====
// Stored on tasks: post (postponements), rolled (days it was missed), waiting, decide, decided. Ledger: rollover/<date>.
function rlCfg(){const r=(state.settings&&state.settings.roll)||{};return {auto:r.auto!==false,todayCap:Math.min(8,Math.max(1,Math.round(Number(r.todayCap))||3)),decideAt:Math.min(9,Math.max(2,Math.round(Number(r.decideAt))||3))};}
const rlDay=d=>fmt(d,{weekday:"short"}),rlDl=d=>fmt(d,{weekday:"short",day:"numeric",month:"short"});
const rlPost=t=>Number(t&&t.post)||0;
const rlTodayIso=()=>iso(new Date());
function rlBuffer(d){const sp=v3spOf(d);return !!sp&&spBufferSet(sp).has(d);}
const rlOff=d=>isFriday(d)||rlBuffer(d);
function rlNeedsDecide(t){return !!t&&!t.done&&rlPost(t)>=rlCfg().decideAt;}
// a task may carry forward unless its project is paused, done or archived
function rlLive(t){if(!t||t.done||t.cut||t.archived||t.inbox||!t.date||t.bucket)return false;const b=state.tasks[chBk(t)];return !(b&&b.bucket&&(b.archived||b.bState==="paused"||b.bState==="done"));}
function rlGroups(tasks){const g=new Map();
  tasks.forEach(t=>{const k=chKind(t),key=k==="design"?"d|"+chBk(t):k;if(!g.has(key))g.set(key,{key,kind:k,bk:k==="design"?chBk(t):null,tasks:[]});g.get(key).tasks.push(t);});
  const kr={design:0,learn:1,shallow:2};
  g.forEach(x=>{x.tasks.sort((a,b)=>(Number(b.pri)||0)-(Number(a.pri)||0)||(a.date<b.date?-1:a.date>b.date?1:0)||(a.order||0)-(b.order||0));
    x.pri=Math.max(...x.tasks.map(t=>Number(t.pri)||0));x.due=x.tasks.map(t=>t.due||"9999").sort()[0];x.oldest=x.tasks.map(t=>t.date).sort()[0];
    x.name=x.kind==="design"?chBkName(x.bk):x.kind==="learn"?"Learning":"Shallow batch";x.mins=x.tasks.reduce((a,t)=>a+estMin(t),0);});
  return [...g.values()].sort((a,b)=>kr[a.kind]-kr[b.kind]||(b.pri-a.pri)||(a.due<b.due?-1:a.due>b.due?1:0)||(a.oldest<b.oldest?-1:a.oldest>b.oldest?1:0));}
// what a day already holds, in minutes per block (skip = ids that are leaving)
function rlSt(d,sim,skip){if(sim[d])return sim[d];const A=chAssign(d,null),S={1:{bk:new Set(),min:0},2:{bk:new Set(),min:0},3:{bk:new Set(),min:0}},st={S,L:0,H:0};
  tasksOn(d).filter(t=>!(skip&&skip.has(t.id))).forEach(t=>{const k=chKind(t),m=estMin(t);if(k==="design"){const s=A.slotOf[t.id]||1;S[s].bk.add(chBk(t));S[s].min+=m;}else if(k==="learn")st.L+=m;else st.H+=m;});
  return sim[d]=st;}
function rlDays(from,n){const out=[];let d=from;for(let i=0;i<n;i++,d=addDays(d,1)){if(v3spOf(d)||!spOn())out.push(d);}return out;}
// place groups, in order, into the first blocks that fit. A chunk stays together and splits only at a block boundary.
// o: {cap:max items, force:a day that is allowed even if rest or buffer, allowBuf:buffer days are allowed, skip:Set of ids leaving}
function rlPlace(groups,days,sim,o){o=o||{};const cfg=chCfg(),placed=[],wait=[];let left=o.cap==null?1e9:o.cap;
  const ok=d=>d===o.force||!(isFriday(d)||(!o.allowBuf&&rlBuffer(d)));
  groups.forEach(g=>{const blocks=[];
    days.filter(ok).forEach(d=>{const st=rlSt(d,sim,o.skip);
      if(g.kind==="design"){const held=[1,2,3].find(n=>st.S[n].bk.has(g.bk));if(held)blocks.push({d,slot:held});[1,2].forEach(n=>{if(n!==held&&!st.S[n].bk.size)blocks.push({d,slot:n});});}
      else blocks.push({d,slot:null});});
    let ci=0,dead=false;
    g.tasks.forEach(t=>{if(dead||left<=0){wait.push(t.id);return;}const m=estMin(t);let hit=null;
      while(ci<blocks.length){const b=blocks[ci],st=rlSt(b.d,sim,o.skip);let min,cap;
        if(g.kind==="design"){min=st.S[b.slot].min;cap=chunkCap(b.d,"b"+b.slot);const other=[...st.S[b.slot].bk].some(x=>x!==g.bk);if(!other&&(min+m<=cap||min===0)){hit=b;break;}}
        else if(g.kind==="learn"){if(st.L+m<=chunkCap(b.d,"learn")||st.L===0){hit=b;break;}}
        else if(st.H+m<=chunkCap(b.d,"shallow")||st.H===0){hit=b;break;}
        ci++;}
      if(!hit){dead=true;wait.push(t.id);return;}
      const st=rlSt(hit.d,sim,o.skip);if(g.kind==="design"){st.S[hit.slot].bk.add(g.bk);st.S[hit.slot].min+=m;}else if(g.kind==="learn")st.L+=m;else st.H+=m;
      left--;placed.push({id:t.id,date:hit.d,slot:hit.slot,mode:modeOf(t),g});});});
  return {placed,wait};}
// write fields to tasks and return what they were, so the change can be put back exactly
let rlSkip=false;
function rlWrite(patches){const old={};rlSkip=true;
  try{Object.entries(patches).forEach(([id,p])=>{const t=state.tasks[id];if(!t)return;old[id]={};Object.keys(p).forEach(k=>{old[id][k]=t[k]===undefined?null:JSON.parse(JSON.stringify(t[k]));});state.tasks[id]={...t,...p};setTask(id,p);});}finally{rlSkip=false;}
  return old;}
function rlRestore(old){chSkip=true;rlSkip=true;try{Object.entries(old||{}).forEach(([id,p])=>{if(!state.tasks[id])return;state.tasks[id]={...state.tasks[id],...p};setTask(id,p);});}finally{chSkip=false;rlSkip=false;}render();}
const rlSpN=d=>{const s=v3spOf(d);return s?s.n:null;};
function rlPlacePatch(p,t,extra){const r={date:p.date,sprint:rlSpN(p.date)!=null?rlSpN(p.date):(t.sprint===undefined?null:t.sprint),slot:p.slot,mode:p.mode,waiting:null};return {...r,...(extra||{})};}
function rlList(names,n){const a=names.slice(0,n);return a.join(", ")+(names.length>n?" and "+(names.length-n)+" more":"");}
const rlTasks=n=>n+" task"+(n===1?"":"s");
// ---- the daily carry-forward ----
let rlTried={};
async function rlRun(today){const cfg=rlCfg(),prevD=(()=>{let d=addDays(today,-1);if(isFriday(d))d=addDays(d,-1);return d;})();
  const cands=leafTasks().filter(t=>rlLive(t)&&t.date<today);
  const ccfg=chCfg(),sim={},carry=[],patches={};
  const groups=rlGroups(cands);
  const days=isFriday(today)?[]:[today];
  const res=rlPlace(groups,days,sim,{cap:cfg.todayCap,allowBuf:true});
  const byId={};cands.forEach(t=>{byId[t.id]=t;});
  res.placed.forEach(p=>{const t=byId[p.id],fresh=!t.waiting,post=rlPost(t)+(fresh?1:0);
    patches[p.id]=rlPlacePatch(p,t,{post,rolled:fresh?[...(t.rolled||[]),t.date].slice(-10):(t.rolled||[]),decide:post>=cfg.decideAt?true:null});carry.push(p);});
  const waitIds=res.wait;
  waitIds.forEach(id=>{const t=byId[id],fresh=!t.waiting,post=rlPost(t)+(fresh?1:0);
    patches[id]={waiting:true,post,rolled:fresh?[...(t.rolled||[]),t.date].slice(-10):(t.rolled||[]),decide:post>=cfg.decideAt?true:null};});
  const old=rlWrite(patches);
  const names=[],seen={};carry.forEach(p=>{const k=p.g.key;if(!seen[k]){seen[k]={g:p.g,n:0};names.push(k);}seen[k].n++;});
  const carried=names.map(k=>({k,name:seen[k].g.name,kind:seen[k].g.kind,n:seen[k].n,ids:carry.filter(p=>p.g.key===k).map(p=>p.id)}));
  const decide=Object.keys(patches).filter(id=>patches[id].decide);
  const wk=pomS(v3workMin(prevD)),tg=pomS(v3dayMin(prevD)),ln=learnDone(prevD);
  const rec={at:Date.now(),day:today,prev:prevD,work:Number(wk),target:Number(tg),learn:ln,learnMin:ccfg.learn.minMin,carried,waiting:waitIds,decide,patches:JSON.stringify(old),n:Object.keys(patches).length,undone:false};
  state.rollover={...(state.rollover||{}),[today]:rec};
  try{await store.set("rollover/"+today,rec);}catch(e){console.warn(e);}
  if(Object.keys(patches).length){render();
    const msg=rlDay(prevD)+": work "+wk+" of "+tg+" h, learning "+ln+" of "+ccfg.learn.minMin+" min."+(carried.length?" Carried: "+rlList(carried.map(c=>c.kind==="design"?c.name+" chunk ("+rlTasks(c.n)+")":c.name+" ("+c.n+")"),2)+".":"")+(waitIds.length?" Waiting: "+waitIds.length+".":"");
    v3undoToast(msg,()=>rlUndo(today));}
  return rec;}
function rlUndo(day){const r=(state.rollover||{})[day];if(!r||r.undone)return false;try{rlRestore(JSON.parse(r.patches||"{}"));}catch(e){console.warn(e);}
  const nr={...r,undone:true,undoneAt:Date.now()};state.rollover={...state.rollover,[day]:nr};try{store.set("rollover/"+day,nr);}catch(e){}toast("Rollover undone");return true;}
function rlAuto(){const today=rlTodayIso(),L=state.loaded||{};if(rlTried[today]||!L.tasks||!L.logs||!L.settings||!L.rollover)return;
  if((state.rollover||{})[today]){rlTried[today]=1;return;}
  rlTried[today]=1;if(!rlCfg().auto)return;if(!Object.keys(state.tasks||{}).length)return;Promise.resolve().then(()=>rlRun(today)).catch(e=>console.warn(e));}
{const _r9=render;render=function(){_r9();try{rlAuto();}catch(e){console.warn(e);}};}
// ---- manual later-moves add 1 to post; a 3rd postponement asks for a decision instead ----
function rlBase(t){const today=rlTodayIso();return t.date<today?today:t.date;}
{const _rsA=rsApply;rsApply=function(id,d,ctx,ws){const ids=[id,...kidsOf(id).map(k=>k.id)],before={};
    ids.forEach(i=>{const x=state.tasks[i];if(x&&isLeaf({...x,id:i}))before[i]={date:x.date,post:rlPost(x),done:!!x.done};});
    const gate=Object.keys(before).map(i=>({i,x:state.tasks[i]})).find(o=>o.x&&!before[o.i].done&&rlNeedsDecide(o.x)&&d>rlBase(o.x));
    if(gate){psClose(true);rlDecideSheet(gate.i);return;}
    const _ut=v3undoToast;let snap=null;v3undoToast=function(m,fn){return _ut.call(this,m,()=>{fn();if(snap)rlRestore(snap);});};Object.defineProperty(v3undoToast,"_t",{get:()=>_ut._t,set:v=>{_ut._t=v;}});
    try{_rsA.apply(this,arguments);}finally{v3undoToast=_ut;}
    snap={};const patches={};Object.entries(before).forEach(([i,b])=>{const x=state.tasks[i];if(x&&!b.done&&x.date&&b.date&&x.date>b.date&&x.date>rlBase({date:b.date})){snap[i]={post:b.post};patches[i]={post:b.post+1};}});
    if(Object.keys(patches).length){rlWrite(patches);render();}};}
{const _mvT=moveTaskTo;moveTaskTo=function(id,d){const t=state.tasks[id],b=t&&isLeaf({...t,id})&&!t.done?{date:t.date,post:rlPost(t)}:null;
    if(b&&d>rlBase(t)&&rlNeedsDecide(t)){rlDecideSheet(id);return;}
    const r=_mvT.apply(this,arguments);const x=state.tasks[id];if(b&&x&&x.date&&x.date>b.date&&x.date>rlBase({date:b.date})){rlWrite({[id]:{post:b.post+1}});render();}return r;};}
// ---- the decision: do now, shrink, split or drop ----
function rlDecideBtns(id,after){const act=(fn)=>()=>{fn();if(after)setTimeout(after,250);};
  return el("div",{class:"rl-da"},
    el("button",{type:"button",class:"mini rl-now",onclick:act(()=>rlDo(id))},"Do now"),
    el("button",{type:"button",class:"mini rl-shrink",onclick:()=>rlShrink(id,after)},"Shrink"),
    el("button",{type:"button",class:"mini rl-split",onclick:act(()=>rlSplit(id))},"Split"),
    el("button",{type:"button",class:"mini rl-drop",onclick:act(()=>rlDrop(id))},"Drop"));}
function rlDecideSheet(id){psOpen("Decide",re=>{const t=state.tasks[id];if(!t)return [el("p",{class:"ps-sh-sum",text:"This task is gone."})];
  return [el("p",{class:"ps-sh-sum",text:t.title}),el("p",{class:"hint",text:"Postponed "+rlPost(t)+" times. Decide: do it now, shrink it, split it or drop it."}),rlDecideBtns(id,()=>psClose(true))];});}
function rlDecidedPatch(t,how,extra){return {post:0,decide:null,decided:{d:rlTodayIso(),how},...(extra||{})};}
function rlDo(id){const t=state.tasks[id];if(!t)return;psClose(true);const today=rlTodayIso(),pl=placeInChunk({...t,id},today);
  const old=rlWrite({[id]:{date:today,sprint:rlSpN(today)!=null?rlSpN(today):t.sprint||null,slot:pl.slot,mode:pl.mode,waiting:null,...rlDecidedPatch(t,"now")}});render();
  v3undoToast("Set for today: "+t.title,()=>rlRestore(old));setTimeout(()=>{try{v3start(id);}catch(e){console.warn(e);}},60);}
function rlShrink(id,after){const t=state.tasks[id];if(!t)return;const cur=estMin(t),opts=[["Half",Math.max(5,Math.round(cur/2/5)*5)],["25 min",25],["15 min",15]].filter(([n,m],i,a)=>m<cur&&a.findIndex(x=>x[1]===m)===i);
  psOpen("Shrink",re=>[el("p",{class:"ps-sh-sum",text:t.title}),el("p",{class:"hint",text:"Now about "+cur+" min. Pick a smaller version you will start."}),
    opts.length?el("div",{class:"v3-cats"},...opts.map(([n,m])=>el("button",{type:"button",class:"cat-chip v3-rs rl-shrink-pick",onclick:()=>{const old=rlWrite({[id]:rlDecidedPatch(t,"shrink",{mins:m})});render();psClose(true);v3undoToast("Shrunk to "+m+" min: "+t.title,()=>rlRestore(old));if(after)setTimeout(after,250);}},n+" · "+m+" min"))):el("p",{class:"hint",text:"Already small. Split or drop it."})]);}
function rlNextOpen(from){let d=from;for(let i=0;i<60;i++,d=addDays(d,1)){if((v3spOf(d)||!spOn())&&!rlOff(d))return d;}return from;}
function rlSplit(id){const t=state.tasks[id];if(!t)return;const half=Math.max(5,Math.round(estMin(t)/2/5)*5),today=rlTodayIso(),nd=rlNextOpen(addDays(t.date<today?today:t.date,1)),base=String(t.title).replace(/\s*\((?:part )?[12] of 2\)$/,"");
  const old=rlWrite({[id]:rlDecidedPatch(t,"split",{mins:half,title:base+" (1 of 2)"})});
  const doc={title:base+" (2 of 2)",cat:t.cat||null,parent:t.parent||null,mins:half,date:nd,sprint:rlSpN(nd),order:(t.order||0)+.5,done:false,post:0,decided:{d:today,how:"split"}};if(t.mode)doc.mode=t.mode;if(t.pri)doc.pri=t.pri;if(t.due)doc.due=t.due;
  let nid=null;Promise.resolve(store.add("tasks",doc)).then(ref=>{nid=ref.id;state.tasks[nid]=doc;render();}).catch(fail);
  render();v3undoToast("Split in two: "+base+". Part 2 on "+rlDl(nd),()=>{rlRestore(old);if(nid){delete state.tasks[nid];try{store.del("tasks/"+nid);}catch(e){}render();}});}
function rlDrop(id){const t=state.tasks[id];if(!t)return;const old=rlWrite({[id]:{archived:true,cut:true,archivedBy:null,waiting:null,decide:null,decided:{d:rlTodayIso(),how:"drop"}}});render();
  v3undoToast("Dropped: "+t.title,()=>rlRestore(old));}
// ---- Waiting tray, Spread, Move chunk ----
function rlWaiting(){return leafTasks().filter(t=>rlLive(t)&&t.waiting);}
function rlSpread(){const today=rlTodayIso(),all=rlWaiting(),dec=all.filter(rlNeedsDecide),ok=all.filter(t=>!rlNeedsDecide(t));
  if(!ok.length){toast(dec.length?"Decide first: "+dec.length+" waiting "+(dec.length===1?"task is":"tasks are")+" postponed too often":"Nothing is waiting");return;}
  const sim={},res=rlPlaceSp(rlGroups(ok),addDays(today,1),60,sim,{}),patches={},by={};
  res.placed.forEach(p=>{const t=state.tasks[p.id];patches[p.id]=rlPlacePatch(p,t);(by[p.g.key]=by[p.g.key]||{g:p.g,days:[]}).days.push(p.date);});
  if(!Object.keys(patches).length){toast("No free block in the next 60 days");return;}
  const old=rlWrite(patches);render();
  const parts=Object.values(by).map(x=>x.g.name+" to "+rlDay(x.days.slice().sort()[0]));
  v3undoToast("Spread: "+rlList(parts,3)+(res.wait.length?". "+res.wait.length+" still waiting":"")+(res.placed.some(p=>p.overflow)?". "+res.placed.filter(p=>p.overflow).length+" to buffer days":"")+(dec.length?". "+dec.length+" to decide":""),()=>rlRestore(old));}
// move a whole chunk to a day; a full or resting day lands on the next block that fits
function rlMoveChunk(tasks,d,typed){const today=rlTodayIso(),open=tasks.filter(t=>rlLive(t)),ok=open.filter(t=>!rlNeedsDecide(t)),dec=open.length-ok.length;
  if(!ok.length){toast(open.length?"Decide first: postponed too often":"Nothing to move");return;}
  const go=()=>{const skip=new Set(ok.map(t=>t.id)),sim={},res=rlPlaceSp(rlGroups(ok),d,40,sim,{skip,force:typed?d:null}),patches={};
    res.placed.forEach(p=>{const t=state.tasks[p.id],later=p.date>rlBase(t);patches[p.id]=rlPlacePatch(p,t,{post:later?rlPost(t)+1:rlPost(t),decide:later&&rlPost(t)+1>=rlCfg().decideAt?true:null});});
    if(!Object.keys(patches).length){toast("No free block from "+rlDl(d));return;}
    const old=rlWrite(patches);psClose(true);render();
    const first=res.placed.map(p=>p.date).sort()[0],g=rlGroups(ok)[0],nm=rlGroups(ok).length>1?rlTasks(Object.keys(patches).length):g.name+" chunk";
    v3undoToast("Moved to "+rlDl(first)+(res.wait.length?". "+res.wait.length+" did not fit":"")+(dec?". "+dec+" to decide":""),()=>rlRestore(old));};
  if(typed&&isFriday(d)){v3confirm("Friday is your rest day. Move to "+rlDl(d)+" anyway?","Move",go);return;}
  go();}
function rlFits(tasks,d){const ok=tasks.filter(t=>rlLive(t)&&!rlNeedsDecide(t)),skip=new Set(ok.map(t=>t.id)),r=rlPlace(rlGroups(ok),[d],{},{skip});return r.placed.length===ok.length;}
function rlMissText(t){const r=(t.rolled||[]).slice(-4);return r.length?"Missed "+r.map(rlDay).join(", ")+((t.rolled||[]).length>4?" and "+((t.rolled||[]).length-4)+" more":""):"";}
function rlWaitSheet(){psOpen("Waiting",re=>{const all=rlWaiting();if(!all.length)return [el("p",{class:"ps-sh-sum",text:"Nothing is waiting."})];
  const groups=rlGroups(all);
  return [el("p",{class:"hint",text:"Whole chunks wait here when today is full. Spread puts each on the next free day. Friday is skipped; buffer days only take what does not fit the planned days."}),
    el("button",{type:"button",class:"btn rl-spread",onclick:()=>{psClose(true);rlSpread();}},"Spread"),
    ...groups.map(g=>el("section",{class:"rl-grp"},el("div",{class:"rl-gh"},el("b",{text:g.name+" · "+rlTasks(g.tasks.length)}),el("span",{class:"hint",text:dur(g.mins)}),el("button",{type:"button",class:"mini rl-gmove",onclick:()=>{psClose(true);setTimeout(()=>rlMoveSheet(g.tasks,g.name),50);}},"Move")),
      el("ul",{class:"cut-list ce-list"},...g.tasks.map(t=>{const cb=el("input",{type:"checkbox","aria-label":"Done: "+t.title});cb.onchange=()=>{setDone(t.id,cb.checked);setTimeout(re,300);};
        return el("li",{class:"cl"},el("div",{class:"cl-row"},cb,el("span",{class:"cl-t",text:t.title}),el("span",{class:"hint",text:rlMissText(t)})),rlNeedsDecide(t)?el("div",{class:"rl-decide"},el("p",{class:"rl-dt",text:"Postponed "+rlPost(t)+" times. Decide:"}),rlDecideBtns(t.id,re)):null);}))))];});}
function rlRenderTray(){const box=document.getElementById("taskList");if(!box)return;let w=document.getElementById("rlWait");const today=rlTodayIso();
  const eb=document.getElementById("cutEarlier"),all=sel>=today?rlWaiting():[];
  if(eb){const ear=sel>=today?leafTasks().filter(t=>rlLive(t)&&t.date<sel&&!t.waiting).length:0;if(!ear){while(eb.firstChild)eb.removeChild(eb.firstChild);}else{const n=eb.querySelector(".ce-n");if(n)n.textContent=String(ear);}}
  if(!all.length){if(w)w.remove();return;}
  if(!w){w=el("div",{id:"rlWait",class:"cut-earlier rl-wait"});}
  const anchor=eb||document.getElementById("cutStack");if(anchor&&w.previousElementSibling!==anchor)anchor.after(w);
  const nd=all.filter(rlNeedsDecide).length;
  rc(w,el("button",{type:"button",class:"ce-head rl-wait-b",onclick:rlWaitSheet},el("span",{text:"Waiting"+(nd?" · "+nd+" to decide":"")}),el("span",{class:"ce-n",text:String(all.length)})));}
{const _rc3=renderCutList;renderCutList=function(){_rc3();try{rlRenderTray();}catch(e){console.warn(e);}};}
// ---- what a card shows: miss history and the decide card ----
function rlFromText(tasks,d){const ds=[...new Set(tasks.filter(t=>!t.done&&t.rolled&&t.rolled.length).map(t=>t.rolled[t.rolled.length-1]).filter(x=>x<d))].sort();
  return ds.length?"from "+(ds.length<=2?ds.map(rlDay).join(", "):ds.length+" days"):"";}
{const _vc3=v3card;v3card=function(t,top,ctx){const c=_vc3(t,top,ctx);try{const steps=t.steps||[t],hist=[...new Set(steps.filter(s=>!s.done).flatMap(s=>s.rolled||[]))].sort();
    const head=c.querySelector(".cs-head");
    if(head&&hist.length){const mt=rlMissText({rolled:hist});head.after(el("p",{class:"hint rl-miss",text:mt}));}
    const dt=steps.find(s=>rlNeedsDecide(s));
    if(dt){const anchor=c.querySelector(".rl-miss")||head;if(anchor)anchor.after(el("div",{class:"rl-decide"},el("p",{class:"rl-dt",text:"Postponed "+rlPost(dt)+" times. Decide:"}),rlDecideBtns(dt.id)));}
  }catch(e){console.warn(e);}return c;};}
// settings and the ledger
function rlLine(r){const d=r.prev||r.day;return rlDl(d)+": work "+r.work+" of "+r.target+" h, learning "+r.learn+" of "+r.learnMin+" min"+(r.carried&&r.carried.length?", carried "+r.carried.reduce((a,c)=>a+c.n,0):"")+(r.waiting&&r.waiting.length?", waiting "+r.waiting.length:"")+(r.undone?" (undone)":"");}
function rlRecent(n){return Object.entries(state.rollover||{}).filter(([k,r])=>r&&r.day).sort((a,b)=>a[0]<b[0]?1:-1).slice(0,n).map(x=>x[1]);}
function rlSave(next,msg){const old=(state.settings||{}).roll||null,v={...next,at:Date.now()};state.settings={...(state.settings||{}),roll:v};try{store.set("settings/roll",v);}catch(e){fail(e);}
  v3undoToast(msg||"Rollover saved",()=>{const s={...(state.settings||{})};if(old){s.roll=old;try{store.set("settings/roll",old);}catch(e){}}else delete s.roll;state.settings=s;render();});render();}
function rlSheet(){psOpen("Rollover",re=>{const c=rlCfg(),today=rlTodayIso(),tr=(state.rollover||{})[today];
    const num=(v,lab,fn,min,max)=>{const i=el("input",{type:"number",class:"v3-in",step:"1",min:String(min),max:String(max),value:String(v),"aria-label":lab});i.onchange=()=>{const n=Math.round(Number(i.value));if(!(n>=min&&n<=max)){toast(lab+": "+min+" to "+max);re();return;}fn(n);setTimeout(re,200);};return el("label",{class:"field"},el("span",{class:"label",text:lab}),i);};
    const recent=rlRecent(10);
    return [el("p",{class:"hint",text:"On the first open of a day, unfinished work moves forward by chunk. At most "+c.todayCap+" carried items show on Today; the rest wait in the Waiting tray."}),
      el("div",{class:"v3-row"},el("button",{type:"button",class:"btn ghost rl-auto","aria-pressed":String(c.auto),onclick:()=>{rlSave({...rlCfgRaw(),auto:!c.auto});setTimeout(re,200);}},c.auto?"Auto rollover: on":"Auto rollover: off")),
      el("div",{class:"v3-row"},num(c.todayCap,"Carried items on Today",v=>rlSave({...rlCfgRaw(),todayCap:v}),1,8),num(c.decideAt,"Decide after postponing",v=>rlSave({...rlCfgRaw(),decideAt:v}),2,9)),
      tr&&!tr.undone&&tr.n?el("button",{type:"button",class:"btn ghost rl-undo",onclick:()=>{rlUndo(today);setTimeout(re,200);}},"Undo today's rollover"):null,
      el("span",{class:"label",text:"History"}),recent.length?el("ul",{class:"ps-sh-list rl-hist"},...recent.map(r=>el("li",{class:"ps-sh-hrow"},el("span",{text:rlLine(r)})))):el("p",{class:"hint",text:"No days recorded yet"})];});}
function rlCfgRaw(){const r=(state.settings&&state.settings.roll)||{};return {auto:r.auto!==false,todayCap:rlCfg().todayCap,decideAt:rlCfg().decideAt};}
function rlRow(){const rows=document.querySelector('.page[data-page="settings"] .set-rows');if(!rows||document.getElementById("rlRow"))return;
  rows.append(el("div",{class:"set-row",id:"rlRow"},el("div",{},el("b",{text:"Rollover"}),el("span",{class:"hint",text:"Carry unfinished work forward, the Waiting tray, decide after 3 postponements"})),el("button",{type:"button",class:"btn ghost",id:"rlBtn",onclick:rlSheet},"Open")));}
function rlReview(){const pg=document.querySelector('.page[data-page="progress"]');if(!pg)return;let s=document.getElementById("rlRev");const L=rlRecent(7);
  if(!L.length){if(s)s.remove();return;}
  if(!s){s=el("section",{class:"panel",id:"rlRev","aria-label":"Carried over"});pg.append(s);}
  rc(s,el("div",{class:"panel-head"},el("h2",{text:"Carried over"}),el("span",{class:"hint",text:"Plan against actual, last "+L.length+" days"})),el("ul",{class:"ps-sh-list rl-hist"},...L.map(r=>el("li",{class:"ps-sh-hrow"},el("span",{text:rlLine(r)})))));}
{const _r10=render;render=function(){_r10();try{rlRow();rlReview();}catch(e){}};}
// Reorder is a gesture: hold a card on the Today list, then drag (see chRender). No Up/Down buttons anywhere.
window.__rl={run:rlRun,undo:rlUndo,spread:rlSpread,waiting:rlWaiting,place:rlPlace,groups:rlGroups,moveChunk:rlMoveChunk,moveSheet:rlMoveSheet,decide:rlDecideSheet,cfg:rlCfg,post:rlPost};
function rlChunkName(c){if(c.kind==="learn")return "Learning";if(c.kind==="shallow")return "Shallow batch";return [...new Set(c.tasks.map(t=>chBkName(chBk(t))))].join(" and ")||"Design";}
